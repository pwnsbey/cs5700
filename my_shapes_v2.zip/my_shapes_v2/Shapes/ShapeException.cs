﻿namespace Shapes
{
    public class ShapeException : System.Exception
    {
        public ShapeException(string message) : base(message) {}
    }
}
